'''
##############################################################################
#
# FILE: Bokeh_Visualization_Test_Gantt.py
#
#
# DESCRIPTION: Test of Bokeh package for calendar visualization
#
# SOFTWARE HISTORY:
# 
# Date         Name               Comment
# 20171027     James Stockton     Initial Coding
# 20171103     James Stockton     v0.1  (basic viz, sent to A3 for comments)
# 20171106     James Stockton     moved some data wrangling to data-ingest code
# 20171109     James Stockton     added date sliders and filter dropdown menu
# 20171113     James Stockton     added checkbox list and 'reset all' button
#
##############################################################################
'''

#%%

##############################################################################
# define data paths, import required packages
##############################################################################

from os.path import dirname, join

import bokeh.models as bkm
import bokeh.plotting as bkp
import bokeh.layouts as bkl

from bokeh.palettes import Category20

#from bokeh.plotting import figure, show, output_notebook, output_file
#from bokeh.models import ColumnDataSource, Range1d
#from bokeh.models.tools import HoverTool
#from datetime import datetime
#from bokeh.charts import Bar

import pandas as pd
import numpy as np
import datetime as dt

from dateutil.relativedelta import relativedelta

bkp.output_notebook()

#use this to create a standalone html file to send to others
bkp.output_file('A3_Gantt_Chart.html') 


datapath = "/home/stocktonjc/Coding/Bokeh/data/"
           
           
#datapath = "C:\\Users\\jstockton\\Documents\\" + \
#           "A3_Ops_Training_Calendar\\Testing\\"

datafile = "Unified_data_CPS_JTIMS_sample.csv"
#datafile = "Unified_data_CPS_JTIMS_sample_manual_cleanup.csv"

# define the output filename
#outputFilename = ""

##############################################################################

#%%

##############################################################################
# Import data, cast datetime objects, build some plotting fields, etc.
##############################################################################

# read in joined data from CPS and JTIMS
working_data = pd.read_csv(datapath + datafile)

# cast the Start and End columns to datetime objects
working_data['Start_Date_JTIMS'] = pd.to_datetime(\
                                              working_data['Start_Date_JTIMS'])
working_data['End_Date_JTIMS'] = pd.to_datetime(working_data['End_Date_JTIMS'])
working_data['Start_CPS'] = pd.to_datetime(working_data['Start_CPS'])
working_data['End_CPS'] = pd.to_datetime(working_data['End_CPS'])

# Gather unique event names
unique_event_name_list_JTIMS = working_data['Event_Name_JTIMS']\
                                     .dropna()\
                                     .unique()\
                                     .tolist()

unique_event_name_list_CPS = working_data['Sqdn_CPS']\
                                     .dropna()\
                                     .unique()\
                                     .tolist()


# build empty dictionary from working_data
CDS_empty_dict = {column:[] for column in working_data.columns}

# build columndatasource for bokeh
CDS_plot = bkm.ColumnDataSource(data = CDS_empty_dict)

#prep description text
desc = bkm.Div(text = open(join(dirname(__file__), 
                      "Master_Exercise_Calendar_text.html")).read(), width=800)

##############################################################################

#%%

##############################################################################
# Build User Input Controls (filters, sliders, etc.)
##############################################################################

# grab curent date
current_date = dt.datetime.now()

# use current date to build the first of the current month 
first_of_month = dt.date(current_date.year, current_date.month, 1)
current_month_plus_year = dt.date(current_date.year + 1, current_date.month, 1)
# prepare month-by-month stepsize for the date slider 
month_step = relativedelta(month = 1)

# find the earliest date that exists in the dataset 
min_CPS_JTIMS_date = min(working_data.Start_Date_JTIMS.min(),\
                         working_data.Start_CPS.min())

# find the latest date in the dataset
max_CPS_JTIMS_date = max(working_data.Start_Date_JTIMS.max(),\
                         working_data.Start_CPS.max())



sizing_mode = 'fixed' # 'fixed'  # 'scale_width' # (other option(s) ?)

squadron_selector_list = ["All",*unique_event_name_list_CPS]

squadron_selector = bkm.widgets.Select(title = "Filter by Squadron",
                                       value = "All",
                                       options = squadron_selector_list)


min_date = bkm.DateSlider(title = "Choose Starting Date",
                          value = first_of_month,
                          start = min_CPS_JTIMS_date - \
                                                  pd.to_timedelta(20,unit='D'),
                          end = max_CPS_JTIMS_date - \
                                                  pd.to_timedelta(20,unit='D'),
                          step = 1)

max_date = bkm.DateSlider(title = "Choose Ending Date",
                          value = current_month_plus_year,
                          start = min_CPS_JTIMS_date - \
                                                  pd.to_timedelta(20,unit='D'),
                          end = max_CPS_JTIMS_date - \
                                                  pd.to_timedelta(20,unit='D'),
                          step = 1)



MAJCOM_list = ['ACC','AETC','AFGSC','AFMC','AFRC','AFSPC',\
               'AFSOC','AMC','PACAF','USAFE']

unique_MAJCOM_list = working_data['MAJCOM_CPS'].dropna().unique().tolist()

MAJCOM_checkbox = bkm.widgets.CheckboxGroup(labels = unique_MAJCOM_list,\
                                          active = [0]*len(unique_MAJCOM_list))

select_all = bkm.widgets.Button(label = "Reset All")

controls = [select_all,
            squadron_selector,
            min_date,
            max_date,
            MAJCOM_checkbox]



##############################################################################

#%%

##############################################################################
# Define callbacks and data update functions when given user input
##############################################################################

def user_select():
    squadron_selector_val = squadron_selector.value
    selected = working_data[
              ( (working_data.Start_Date_JTIMS >= min_date.value) |
                (working_data.Start_CPS >= min_date.value) ) &
              ( (working_data.End_Date_JTIMS <= max_date.value) |
                (working_data.End_CPS <= max_date.value) )
              ]
#        (CDS.Sqdr_CPS >= reviews.value) &
#        (movies.BoxOffice >= (boxoffice.value * 1e6)) &
       
#        (movies.Year <= max_year.value) &
#        (movies.Oscars >= oscars.value)
   
    if (squadron_selector_val != "All"):
        selected = selected[selected.Sqdn_CPS.str.contains(\
                                                  squadron_selector_val)==True]
#    if (director_val != ""):
#        selected = selected[selected.Director.str.contains(director_val)==True]
#    if (cast_val != ""):
#        selected = selected[selected.Cast.str.contains(cast_val)==True]  
  
    return selected


def update():
    df_temp = user_select()
#    x_name = axis_map[x_axis.value]
#    y_name = axis_map[y_axis.value]

#    p.xaxis.axis_label = x_axis.value
#    p.yaxis.axis_label = y_axis.value
#    p.title.text = "%d movies selected" % len(df)
    CDS_plot.data = {column:df_temp[column] for column in df_temp.columns}
#    source.data = dict(
#        x=df[x_name],
#        y=df[y_name],
#        color=df["color"],
#        title=df["Title"],
#        year=df["Year"],
#        revenue=df["revenue"],
#        alpha=df["alpha"],
#    )
    
def reset_all():
  squadron_selector.value = "All"
  MAJCOM_checkbox.active = [0]*len(unique_MAJCOM_list)
  min_date.value = first_of_month  
#  min_date.value = min_CPS_JTIMS_date - pd.to_timedelta(20,unit='D')
  max_date.value = max_CPS_JTIMS_date + pd.to_timedelta(20,unit='D')
  update





#  print("test")


#for control in controls:
#  control.on_change('value', lambda attr, old, new: update())

squadron_selector.on_change('value', lambda attr, old, new: update())
min_date.on_change('value', lambda attr, old, new: update())
max_date.on_change('value', lambda attr, old, new: update())
select_all.on_click(reset_all)
#MAJCOM_checkbox.on_click(dummy)

       
inputs = bkm.WidgetBox(*controls, sizing_mode = sizing_mode)

##############################################################################

#%%


##############################################################################
# Build the JTIMS Gantt chart
##############################################################################



# Build list of category colors based on the number of unique entries
if len(unique_event_name_list_JTIMS) > 2:
  color_palette_JTIMS = Category20[len(unique_event_name_list_JTIMS)]
elif len(unique_event_name_list_JTIMS) == 2:
  color_palette_JTIMS = [Category20[3][0],Category20[3][1]]
else:
  color_palette_JTIMS = [Category20[3][0]]    
    


# Make a CategoricalColorMapper object
color_mapper_JTIMS = bkm.CategoricalColorMapper(
                                        factors = unique_event_name_list_JTIMS,
                                        palette = color_palette_JTIMS)


# find the date range for JTIMS events
#JTIMS_date_range = bkm.Range1d(working_data.Start_Date_JTIMS.min() - \
#                                                 pd.to_timedelta(20,unit='D'),\
#                               working_data.End_Date_JTIMS.max() + \
#                                                 pd.to_timedelta(20,unit='D')
#                                                 )


# declare the initial figure
Gantt_JTIMS = bkp.figure(title = 'JTIMS Calendar',
                         x_axis_type = 'datetime',
                         width = 1000,
                         height = 300,
                         y_range = working_data['Event_Name_JTIMS']\
                                               .dropna()\
                                               .unique()\
                                               .tolist(),
#                         x_range = JTIMS_date_range,
                         tools = 'reset,save,hover,tap')


hover_JTIMS = Gantt_JTIMS.select(type=bkm.HoverTool)[0]
hover_JTIMS.tooltips =  [('Event #','@Event_Num_JTIMS'),
                         ('MAJCOM','@MAJCOM_CPS'),
                         ('NAF','@NAF_CPS'),
                         ('Wing','@Wing_CPS'),
                         ('Squadron','@Sqdn_CPS'),
                         ('Qty','@Qty_CPS'),
                         ('Mission Area','@Msn_Area_CPS'),
                         ('JTIMS User Group','@User_Group_JTIMS'),
                         ('Start','@str_Start_Date_JTIMS'),
                         ('End','@str_End_Date_JTIMS'),
                         ('Objectives','@objective_JTIMS')
                        ]



Gantt_JTIMS.quad(left = 'Start_Date_JTIMS',
           right = 'End_Date_JTIMS',
           top = 'plot_top_JTIMS',
           bottom = 'plot_bottom_JTIMS',
           fill_alpha = 'fill_mapping',
#           legend = 'Event_Name_JTIMS',
           source = CDS_plot,
           color = dict(field = 'Event_Name_JTIMS',
                        transform = color_mapper_JTIMS),
           line_color = 'black',
           line_width = 1.5,
           selection_color = "black"
           )

#date_slider_JTIMS = bkm.widgets.DateRangeSlider()

# pass the CDS here too
labels_JTIMS = bkm.LabelSet(x = 'Start_Date_JTIMS',
                      x_units = 'data',
                      y = 'End_Date_JTIMS',
                      y_units = 'data',
                      text = 'str_Start_Date_JTIMS',
                      text_align = 'center',
                      level = 'glyph',
#                      x_offset=5,
#                      y_offset=5,
                      source=CDS_plot)


Gantt_JTIMS.add_layout(labels_JTIMS)

##############################################################################

#%%

##############################################################################
# Build the CPS Gantt chart
##############################################################################


# Build list of category colors based on the number of unique entries
if len(unique_event_name_list_CPS) > 2:
  color_palette_CPS = Category20[len(unique_event_name_list_CPS)]
elif len(unique_event_name_list_CPS) == 2:
  color_palette_CPS = [Category20[3][0],Category20[3][1]]
else:
  color_palette_CPS = [Category20[3][0]] 


# Make a CategoricalColorMapper object
color_mapper_CPS = bkm.CategoricalColorMapper(
                                          factors = unique_event_name_list_CPS,
                                          palette = color_palette_CPS)


#CPS_date_range = bkm.Range1d(working_data.Start_CPS.min() - \
#                                                 pd.to_timedelta(20,unit='D'),\
#                               working_data.End_CPS.max() + \
#                                                 pd.to_timedelta(20,unit='D')
#                                                 )

# declare the initial figure
Gantt_CPS = bkp.figure(title = 'CPS Calendar',
                       x_axis_type = 'datetime',
                       width = 1000,
                       height = 300,
                       y_range = working_data['Sqdn_CPS']\
                                             .dropna()\
                                             .unique()\
                                             .tolist(),
                       x_range = Gantt_JTIMS.x_range,
                       tools = 'reset,save,hover')


hover_CPS = Gantt_CPS.select(type=bkm.HoverTool)[0]
hover_CPS.tooltips =  [('Event','@Event_Name_CPS'),
                       ('NAF','@NAF_CPS'),
                       ('Wing','@Wing_CPS'),
                       ('Qty','@Qty_CPS'),
                       ('Mission Area','@Msn_Area_CPS'),
                       ('JTIMS User Group','@User_Group_JTIMS'),
                       ('Start','@str_Start_Date_CPS'),
                       ('End','@str_End_Date_CPS')
                      ]


Gantt_CPS.quad(left = 'Start_CPS',
           right = 'End_CPS',
           top = 'plot_top_CPS',
           bottom = 'plot_bottom_CPS',
           fill_alpha = 'fill_mapping',
#           legend = 'Event_Name_JTIMS',
           source = CDS_plot,
           color = dict(field = 'Sqdn_CPS',
                        transform = color_mapper_CPS),
           line_color = 'black',
           line_width = 1.5
           )


# pass the CDS here too
labels_CPS = bkm.LabelSet(x = 'Start_CPS',
                      x_units = 'data',
                      y = 'End_CPS',
                      y_units = 'data',
                      text = 'str_Start_Date_CPS',
                      text_align = 'center',
                      level = 'glyph',
#                      x_offset=5,
#                      y_offset=5,
                      source=CDS_plot)


Gantt_CPS.add_layout(labels_CPS)




#p1.text(0, 0, text='color', text_color='text_color',
#        alpha=0.6667, text_font_size='36pt', text_baseline='middle',
#        text_align='center', source=source)


##############################################################################

#%%

##############################################################################
# Update data based on user choices then display the result
##############################################################################

update() # initial load of the data 

#bkp.show(Gantt_CPS)

#final_visualization = bkl.layout([[squadron_selector],
#                                  [min_date],
#                                  [max_date],
#                                  bkl.column(Gantt_JTIMS, Gantt_CPS)])

final_visualization = bkl.layout([[desc],bkl.row(inputs,
                                         bkl.column(Gantt_JTIMS, Gantt_CPS))])

#bkp.show(final_visualization)

bkp.curdoc().add_root(final_visualization)
bkp.curdoc().title = "Master Exercise Calendar"

# =============================================================================
# # delcare the initial figure
# Gantt = bkp.figure(title = 'Project Schedule',
#                    x_axis_type = 'datetime',
#                    width = 1600,
#                    height = 400,
#                    y_range = DF['Item'].unique().tolist(),
#                    x_range = bkm.Range1d(DF.Start_dt.min() - \
#                                                  pd.to_timedelta(10,unit='D'),\
#                                          DF.End_dt.max() + \
#                                                  pd.to_timedelta(10,unit='D')),
#                    tools = 'save')
# 
# glyph_list = {}
# glyph_prep = {}
# glyph_hover = {}
# 
# unique_entity_list = DF['Item'].unique().tolist()
# 
# for unique_entity_name in unique_entity_list:
#   entity_count = len(DF['Item'].where(DF['Item'] == unique_entity_name)\
#                            .dropna()\
#                            .tolist())
#   top_draw_line = 0.25 + int(unique_entity_list.index(unique_entity_name))
#   bottom_draw_line = 0.75 + int(unique_entity_list.index(unique_entity_name))
#   
#   for record in range(entity_count):  
#     CDS = bkm.ColumnDataSource(pd.DataFrame(\
#                                     DF.where(DF['Item'] == unique_entity_name)\
#                                     .dropna()\
#                                     .iloc[record])\
#                                  .transpose())
#     glyph_list[str(unique_entity_name) + "_" + str(record)] = bkm.glyphs.Quad(\
#                                                      left = 'Start_dt',
#                                                      right = 'End_dt',
#                                                      bottom = bottom_draw_line, 
#                                                      top = top_draw_line,
#                                                      fill_color = "Color",
#                                                      fill_alpha = 0.4)
#     
#     glyph_prep[str(unique_entity_name) + "_" + str(record)] = Gantt.add_glyph(
#                source_or_glyph = CDS, \
#                glyph = glyph_list[str(unique_entity_name) + "_" + str(record)])
# 
#     glyph_hover[str(unique_entity_name) + "_" + str(record)] = \
#                              bkm.tools.HoverTool(renderers = \
#                     [glyph_prep[str(unique_entity_name) + "_" + str(record)]],\
#                                             tooltips = [('Task: ', '@Item'),\
#                                                         ('Start: ', '@Start'),\
#                                                         ('End: ', '@End')])
#     
#     Gantt.add_tools(glyph_hover[str(unique_entity_name) + "_" + str(record)])  
# 
# bkp.show(Gantt)
# =============================================================================


# =============================================================================
# source = bkm.ColumnDataSource(data=your_frame)
# p = bkp.figure(tools='add the tools you want here, but no hover!')
# g1 = bkm.Cross(x='col1', y='col2')
# g1_r = p.add_glyph(source_or_glyph=source, glyph=g1)
# g1_hover = bkm.HoverTool(renderers=[g1_r],
#                          tooltips=[('x', '@col1'), ('y', '@col2')])
# p.add_tools(g1_hover)
# =============================================================================
