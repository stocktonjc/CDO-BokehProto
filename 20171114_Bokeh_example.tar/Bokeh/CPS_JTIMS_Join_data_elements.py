'''
##############################################################################
#
# FILE: CPS_JTIMS_Join_data_elements.py
#
#
# DESCRIPTION: basic prototype join of two dataframes each with tiny extracts 
#              from JTIMS and CPS (not all fields)
#
# SOFTWARE HISTORY:
# 
# Date         Name               Comment
# 20171023     James Stockton     Initial Coding, data ingest
# 20171106     James Stockton     moved some data wrangling from viz-code
#
##############################################################################
'''

#%%

##############################################################################
# define data paths, import required packages
##############################################################################

import pandas as pd
#from pandas import ExcelFile
           
#datapath = "C:\\Users\\jstockton\\Documents\\" + \
#           "A3_Ops_Training_Calendar\\Testing\\"

datapath = "/home/stocktonjc/Coding/Bokeh/data/"

datafile = "data_samples_A3_Calendar.xlsx"

# define the output filename
outputFilename = "Unified_data_CPS_JTIMS_sample.csv"

##############################################################################

#%%

##############################################################################
# Read in the data and manipulate it into shape
##############################################################################


# read in CPS excel copy/paste "extract"
CPS_working_data = pd.read_excel(datapath + datafile,\
                                 sheetname = "CPS_mini_data")

# read in JTIMS excel copy/paste "extract"
JTIMS_working_data = pd.read_excel(datapath + datafile,\
                                   sheetname = "JTIMS_mini_data") 


# cast the Start and End columns to datetime objects
CPS_working_data['Start'] = pd.to_datetime(CPS_working_data['Start'])
CPS_working_data['End'] = pd.to_datetime(CPS_working_data['End'])


# temporary fix:  manually add zeros where needed:  18-1 becomes 18-01
CPS_working_data['Event #'].iloc[0] = "18-01"
CPS_working_data['Event #'].iloc[2] = "18-01"
CPS_working_data['Event #'].iloc[3] = "18-01 FW"
CPS_working_data['Event #'].iloc[4] = "18-01 FW"
CPS_working_data['Event #'].iloc[5] = "18-02"


# JTIMS Events stored as a single column. Combine the 2 cols in CPS to 1
CPS_working_data['Events'] = CPS_working_data['Event'] + \
                             " " + \
                             CPS_working_data['Event #']

CPS_working_data['Events_no_spaces'] = CPS_working_data['Events']\
                                                       .str\
                                                       .replace(" ", "")

JTIMS_working_data['Events_no_spaces'] = JTIMS_working_data['Events']\
                                                           .str\
                                                           .replace(" ", "")

JTIMS_working_data['objective'] = "text from JTIMS about objectives"


CPS_working_data.columns = CPS_working_data.columns.str.cat(\
                               others = ["CPS"]*len(CPS_working_data.columns),\
                               sep = "_")

JTIMS_working_data.columns = JTIMS_working_data.columns.str.cat(\
                           others = ["JTIMS"]*len(JTIMS_working_data.columns),\
                           sep = "_")

JTIMS_working_data['Event_Name_JTIMS'] = \
                                    JTIMS_working_data['Events_JTIMS'].str[:-6]

CPS_working_data['Event_Name_CPS'] = CPS_working_data['Events_CPS'].str[:-6]

JTIMS_working_data['Event_Num_JTIMS'] = \
                                    JTIMS_working_data['Events_JTIMS'].str[-5:]

# replace spaces with underscores and octothorpes with 'Num'
CPS_working_data.columns = CPS_working_data.columns.str.replace(" ", "_")
JTIMS_working_data.columns = JTIMS_working_data.columns.str.replace(" ", "_")
CPS_working_data.columns = CPS_working_data.columns.str.replace("#", "Num")
JTIMS_working_data.columns = JTIMS_working_data.columns.str.replace("#", "Num")

       
                                                                    
# create a string label from the 
JTIMS_working_data['str_Start_Date_JTIMS'] = \
       [x.strftime("%Y-%m-%d") for x in JTIMS_working_data['Start_Date_JTIMS']]
JTIMS_working_data['str_End_Date_JTIMS'] = \
         [x.strftime("%Y-%m-%d") for x in JTIMS_working_data['End_Date_JTIMS']]

CPS_working_data['str_Start_Date_CPS'] = \
       [x.strftime("%Y-%m-%d") for x in CPS_working_data['Start_CPS']]
CPS_working_data['str_End_Date_CPS'] = \
         [x.strftime("%Y-%m-%d") for x in CPS_working_data['End_CPS']]




# Gather unique event names
unique_event_name_list_JTIMS = JTIMS_working_data['Event_Name_JTIMS']\
                                     .dropna()\
                                     .unique()\
                                     .tolist()

unique_event_name_list_CPS = CPS_working_data['Sqdn_CPS']\
                                     .dropna()\
                                     .unique()\
                                     .tolist()



# given an event name, determine where that name is in the unique name list
def JTIMS_y_position_mapper(string):
    return int(unique_event_name_list_JTIMS.index(string))

JTIMS_working_data['plot_top_JTIMS'] = 0.75 + \
            JTIMS_working_data['Event_Name_JTIMS'].map(JTIMS_y_position_mapper)

JTIMS_working_data['plot_bottom_JTIMS'] = 0.25 + \
            JTIMS_working_data['Event_Name_JTIMS'].map(JTIMS_y_position_mapper)

# Ditto for CPS
def CPS_y_position_mapper(string):
    return int(unique_event_name_list_CPS.index(string))

CPS_working_data['plot_top_CPS'] = 0.75 + \
                        CPS_working_data['Sqdn_CPS'].map(CPS_y_position_mapper)

CPS_working_data['plot_bottom_CPS'] = 0.25 + \
                        CPS_working_data['Sqdn_CPS'].map(CPS_y_position_mapper)



working_data = pd.merge(left = JTIMS_working_data,\
                        right = CPS_working_data,\
                        how = "outer",\
                        left_on =JTIMS_working_data['Events_no_spaces_JTIMS'],\
                        right_on = CPS_working_data['Events_no_spaces_CPS'])

working_data['fill_mapping'] = None
temp_mask = working_data['Event_CPS'].isnull() 
for ii in range(len(working_data)):
  if temp_mask[ii]:
    working_data['fill_mapping'].iloc[ii] = 0.075 
  else:
    working_data['fill_mapping'].iloc[ii] = 0.9



##############################################################################

#%%

##############################################################################
# Write out the results
##############################################################################
                                   
# write out the result to the provided output filename
#working_data.to_csv(datapath + outputFilename)  
  
##############################################################################