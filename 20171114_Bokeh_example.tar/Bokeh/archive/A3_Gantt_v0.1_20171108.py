'''
##############################################################################
#
# FILE: Bokeh_Visualization_Test_Gantt.py
#
#
# DESCRIPTION: Test of Bokeh package for calendar visualization
#
# SOFTWARE HISTORY:
# 
# Date         Name               Comment
# 20171027     James Stockton     Initial Coding
# 20171103     James Stockton     v0.1  (basic viz, sent to A3 for comments)
# 20171106     James Stockton     moved some data wrangling to data-ingest code
#
##############################################################################
'''

#%%

##############################################################################
# define data paths, import required packages
##############################################################################

#import numpy as np

#import bokeh

import bokeh.models as bkm
import bokeh.plotting as bkp
import bokeh.layouts as bkl

from bokeh.palettes import Category20

#from bokeh.plotting import figure, show, output_notebook, output_file
#from bokeh.models import ColumnDataSource, Range1d
#from bokeh.models.tools import HoverTool
#from datetime import datetime
#from bokeh.charts import Bar

import pandas as pd
import numpy as np

bkp.output_notebook()

#use this to create a standalone html file to send to others
bkp.output_file('A3_Gantt_Chart.html') 


datapath = "/home/stocktonjc/Coding/Bokeh/"
           
           
#datapath = "C:\\Users\\jstockton\\Documents\\" + \
#           "A3_Ops_Training_Calendar\\Testing\\"

datafile = "Unified_data_CPS_JTIMS_sample.csv"
#datafile = "Unified_data_CPS_JTIMS_sample_manual_cleanup.csv"

# define the output filename
#outputFilename = ""

##############################################################################

#%%

##############################################################################
# Import data, cast datetime objects, build some plotting fields, etc.
##############################################################################

# read in joined data from CPS and JTIMS
working_data = pd.read_csv(datapath + datafile)

# cast the Start and End columns to datetime objects
working_data['Start_Date_JTIMS'] = pd.to_datetime(\
                                              working_data['Start_Date_JTIMS'])
working_data['End_Date_JTIMS'] = pd.to_datetime(working_data['End_Date_JTIMS'])
working_data['Start_CPS'] = pd.to_datetime(working_data['Start_CPS'])
working_data['End_CPS'] = pd.to_datetime(working_data['End_CPS'])

# Gather unique event names
unique_event_name_list_JTIMS = working_data['Event_Name_JTIMS']\
                                     .dropna()\
                                     .unique()\
                                     .tolist()

unique_event_name_list_CPS = working_data['Sqdn_CPS']\
                                     .dropna()\
                                     .unique()\
                                     .tolist()

# build columndatasource for bokeh
CDS = bkm.ColumnDataSource(data = working_data)

##############################################################################

#%%

##############################################################################
# Build the JTIMS Gantt chart
##############################################################################



# Build list of category colors based on the number of unique entries
if len(unique_event_name_list_JTIMS) > 2:
  color_palette_JTIMS = Category20[len(unique_event_name_list_JTIMS)]
elif len(unique_event_name_list_JTIMS) == 2:
  color_palette_JTIMS = [Category20[3][0],Category20[3][1]]
else:
  color_palette_JTIMS = [Category20[3][0]]    
    


# Make a CategoricalColorMapper object
color_mapper_JTIMS = bkm.CategoricalColorMapper(
                                        factors = unique_event_name_list_JTIMS,
                                        palette = color_palette_JTIMS)

# find the date range for JTIMS events
JTIMS_date_range = bkm.Range1d(working_data.Start_Date_JTIMS.min() - \
                                                 pd.to_timedelta(20,unit='D'),\
                               working_data.End_Date_JTIMS.max() + \
                                                 pd.to_timedelta(20,unit='D')
                                                 )


# declare the initial figure
Gantt_JTIMS = bkp.figure(title = 'Joint Exercise Calendar',
         x_axis_type = 'datetime',
         width = 1000,
         height = 300,
         y_range = working_data['Event_Name_JTIMS']\
                               .dropna()\
                               .unique()\
                               .tolist(),
         x_range = JTIMS_date_range,
         tools = 'reset,save,hover'
         )

hover_JTIMS = Gantt_JTIMS.select(type=bkm.HoverTool)[0]
hover_JTIMS.tooltips =  [('Event #','@Event_Num_JTIMS'),
                         ('MAJCOM','@MAJCOM_CPS'),
                         ('NAF','@NAF_CPS'),
                         ('Wing','@Wing_CPS'),
                         ('Squadron','@Sqdn_CPS'),
                         ('Qty','@Qty_CPS'),
                         ('Mission Area','@Msn_Area_CPS'),
                         ('JTIMS User Group','@User_Group_JTIMS'),
                         ('Start','@str_Start_Date_JTIMS'),
                         ('End','@str_End_Date_JTIMS'),
                         ('link','@html')
                        ]


Gantt_JTIMS.quad(left = 'Start_Date_JTIMS',
           right = 'End_Date_JTIMS',
           top = 'plot_top_JTIMS',
           bottom = 'plot_bottom_JTIMS',
           fill_alpha = 0.5,
#           legend = 'Event_Name_JTIMS',
           source = CDS,
           color = dict(field = 'Event_Name_JTIMS',
                        transform = color_mapper_JTIMS),
           line_color = 'black',
           line_width = 1.5
           )


# pass the CDS here too
labels_JTIMS = bkm.LabelSet(x = 'Start_Date_JTIMS',
                      x_units = 'data',
                      y = 'End_Date_JTIMS',
                      y_units = 'data',
                      text = 'str_Start_Date_JTIMS',
                      text_align = 'center',
                      level = 'glyph',
#                      x_offset=5,
#                      y_offset=5,
                      source=CDS)


Gantt_JTIMS.add_layout(labels_JTIMS)

##############################################################################

#%%

##############################################################################
# Build the CPS Gantt chart
##############################################################################


# Build list of category colors based on the number of unique entries
if len(unique_event_name_list_CPS) > 2:
  color_palette_CPS = Category20[len(unique_event_name_list_CPS)]
elif len(unique_event_name_list_CPS) == 2:
  color_palette_CPS = [Category20[3][0],Category20[3][1]]
else:
  color_palette_CPS = [Category20[3][0]] 


# Make a CategoricalColorMapper object
color_mapper_CPS = bkm.CategoricalColorMapper(
                                          factors = unique_event_name_list_CPS,
                                          palette = color_palette_CPS)


CPS_date_range = bkm.Range1d(working_data.Start_CPS.min() - \
                                                 pd.to_timedelta(20,unit='D'),\
                               working_data.End_CPS.max() + \
                                                 pd.to_timedelta(20,unit='D')
                                                 )

# declare the initial figure
Gantt_CPS = bkp.figure(title = 'CPS Calendar',
         x_axis_type = 'datetime',
         width = 1000,
         height = 300,
         y_range = working_data['Sqdn_CPS']\
                               .dropna()\
                               .unique()\
                               .tolist(),
         x_range = CPS_date_range,
         tools = 'reset,save,hover'
         )

hover_CPS = Gantt_CPS.select(type=bkm.HoverTool)[0]
hover_CPS.tooltips =  [('Event','@Event_Name_CPS'),
                       ('NAF','@NAF_CPS'),
                       ('Wing','@Wing_CPS'),
                       ('Qty','@Qty_CPS'),
                       ('Mission Area','@Msn_Area_CPS'),
                       ('JTIMS User Group','@User_Group_JTIMS'),
                       ('Start','@str_Start_Date_CPS'),
                       ('End','@str_End_Date_CPS')
                      ]


Gantt_CPS.quad(left = 'Start_CPS',
           right = 'End_CPS',
           top = 'plot_top_CPS',
           bottom = 'plot_bottom_CPS',
           fill_alpha = 0.5,
#           legend = 'Event_Name_JTIMS',
           source = CDS,
           color = dict(field = 'Sqdn_CPS',
                        transform = color_mapper_CPS),
           line_color = 'black',
           line_width = 1.5
           )


# pass the CDS here too
labels_CPS = bkm.LabelSet(x = 'Start_CPS',
                      x_units = 'data',
                      y = 'End_CPS',
                      y_units = 'data',
                      text = 'str_Start_Date_CPS',
                      text_align = 'center',
                      level = 'glyph',
#                      x_offset=5,
#                      y_offset=5,
                      source=CDS)


Gantt_CPS.add_layout(labels_CPS)




#p1.text(0, 0, text='color', text_color='text_color',
#        alpha=0.6667, text_font_size='36pt', text_baseline='middle',
#        text_align='center', source=source)


##############################################################################

#%%

##############################################################################
# Throw the two figures together and display the result
##############################################################################

#bkp.show(Gantt_CPS)

final_visualization = bkl.column(Gantt_JTIMS, Gantt_CPS)


bkp.show(final_visualization)


# =============================================================================
# # delcare the initial figure
# Gantt = bkp.figure(title = 'Project Schedule',
#                    x_axis_type = 'datetime',
#                    width = 1600,
#                    height = 400,
#                    y_range = DF['Item'].unique().tolist(),
#                    x_range = bkm.Range1d(DF.Start_dt.min() - \
#                                                  pd.to_timedelta(10,unit='D'),\
#                                          DF.End_dt.max() + \
#                                                  pd.to_timedelta(10,unit='D')),
#                    tools = 'save')
# 
# glyph_list = {}
# glyph_prep = {}
# glyph_hover = {}
# 
# unique_entity_list = DF['Item'].unique().tolist()
# 
# for unique_entity_name in unique_entity_list:
#   entity_count = len(DF['Item'].where(DF['Item'] == unique_entity_name)\
#                            .dropna()\
#                            .tolist())
#   top_draw_line = 0.25 + int(unique_entity_list.index(unique_entity_name))
#   bottom_draw_line = 0.75 + int(unique_entity_list.index(unique_entity_name))
#   
#   for record in range(entity_count):  
#     CDS = bkm.ColumnDataSource(pd.DataFrame(\
#                                     DF.where(DF['Item'] == unique_entity_name)\
#                                     .dropna()\
#                                     .iloc[record])\
#                                  .transpose())
#     glyph_list[str(unique_entity_name) + "_" + str(record)] = bkm.glyphs.Quad(\
#                                                      left = 'Start_dt',
#                                                      right = 'End_dt',
#                                                      bottom = bottom_draw_line, 
#                                                      top = top_draw_line,
#                                                      fill_color = "Color",
#                                                      fill_alpha = 0.4)
#     
#     glyph_prep[str(unique_entity_name) + "_" + str(record)] = Gantt.add_glyph(
#                source_or_glyph = CDS, \
#                glyph = glyph_list[str(unique_entity_name) + "_" + str(record)])
# 
#     glyph_hover[str(unique_entity_name) + "_" + str(record)] = \
#                              bkm.tools.HoverTool(renderers = \
#                     [glyph_prep[str(unique_entity_name) + "_" + str(record)]],\
#                                             tooltips = [('Task: ', '@Item'),\
#                                                         ('Start: ', '@Start'),\
#                                                         ('End: ', '@End')])
#     
#     Gantt.add_tools(glyph_hover[str(unique_entity_name) + "_" + str(record)])  
# 
# bkp.show(Gantt)
# =============================================================================


# =============================================================================
# source = bkm.ColumnDataSource(data=your_frame)
# p = bkp.figure(tools='add the tools you want here, but no hover!')
# g1 = bkm.Cross(x='col1', y='col2')
# g1_r = p.add_glyph(source_or_glyph=source, glyph=g1)
# g1_hover = bkm.HoverTool(renderers=[g1_r],
#                          tooltips=[('x', '@col1'), ('y', '@col2')])
# p.add_tools(g1_hover)
# =============================================================================
